const idAudioElement='audioElement';const idPlayingPrefix='#playingPrefixMarkup';const idPlayingSuffix='#playingStation';const idVolumeIcon='#volumeIcon';const classVolumeButton='.volumeBtn';const classRadioStationItem='.container-item';const classPlayer='.player';const classPlaying='.playing';const classStopButton='.stop';const classMuteVolume='fa fa-volume-off';const classDescription='.desc';const classNormalVolume='fa fa-volume-up';const sourceUrlAttribute='data-audioUrl';const hebPlaying='מנגן: ';function getPlayer(callback){chrome.runtime.getBackgroundPage(function(page){var player=page.document.getElementById(idAudioElement);callback(player)})};function getPlayerOptions(callback){chrome.runtime.getBackgroundPage(function(page){var player=page.document.getElementById(idAudioElement);var hls=page.HLS.getInstance();callback(player,hls)})}
function getHls(callback){chrome.runtime.getBackgroundPage(function(page){callback(page.HLS.getInstance())})}
function clearPlayingView(){$(classRadioStationItem).removeClass(classPlaying);$(classPlayer).slideToggle()}
function stopAudio(player){player.pause();player.currentTime=0;player.src="";}
function stopHls(hls){hls.stopLoad();hls.detachMedia()}
function loadHlsMedia(hls,player){hls.loadSource(player.src);hls.attachMedia(player)}
function stopPlaying(player,hls){stopAudio(player);stopHls(hls)}
function updatePlayingInfo(radioStationName){$(idPlayingPrefix).text(hebPlaying);$(idPlayingSuffix).text(radioStationName)}
function toggleVolume(player){player.muted=!player.muted;var volumeIcon=$(idVolumeIcon);if(player.muted){volumeIcon.removeClass();volumeIcon.addClass(classMuteVolume)}
else{volumeIcon.removeClass();volumeIcon.addClass(classNormalVolume)}}
function updatePlayer(player,hls,context){player.src=$(context).attr(sourceUrlAttribute);player.dataset.stationName=$(context).find(classDescription).text();stopHls(hls);if(player.src.endsWith("m3u8")){loadHlsMedia(hls,player)}
player.load();try
{let playPromise=player.play();if(playPromise!==null){playPromise.catch(error=>{if(!isPlaying(player)){$(classPlayer).hide()}})}}
catch(e){stopPlaying(player,hls)}}
function isPlaying(player){return(!player.paused||player.currentTime!=0)}
function initView(){getPlayer(function(player){if(!isPlaying(player)){$(classPlayer).hide()}
else{updatePlayingInfo(player.dataset.stationName)}})}
function togglePlayingView(){if($(classPlayer).is(":hidden")){$(classPlayer).slideToggle("medium")}}
function radioStationChanged(context,player){return $(context).attr(sourceUrlAttribute)!==player.src}
function markPlayingStation(context){$(context).addClass(classPlaying);$(classRadioStationItem).not(context).removeClass(classPlaying)}
function registerEventListeners(){$(classStopButton).click(function(){getPlayerOptions(function(player,hls){stopPlaying(player,hls);clearPlayingView()})});$(classVolumeButton).click(function(){getPlayer(function(player){toggleVolume(player)})});$(classRadioStationItem).click(function(){var context=this;getPlayerOptions((player,hls)=>{if(radioStationChanged(context,player))
{stopPlaying(player,hls);updatePlayingInfo($(context).find(classDescription).text());markPlayingStation(context);updatePlayer(player,hls,context);togglePlayingView()}})})}
$(document).ready(function(){initView();registerEventListeners()})