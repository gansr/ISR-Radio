function showOnPage(value){
	chrome.runtime.sendMessage({msg: value});
}

var audioElement = document.createElement('audio');
 audioElement.setAttribute("preload", "auto");
 audioElement.id = 'audioElement';
 audioElement.style.display = 'none';
 audioElement.autobuffer = true;

 audioElement.addEventListener("error", function(e) {
   switch (e.target.error.code) {
     case e.target.error.MEDIA_ERR_ABORTED:
       showOnPage('You aborted the media playback.');
       break;
     case e.target.error.MEDIA_ERR_NETWORK:
	   showOnPage('A network error caused the audio download to fail.');
       break;
     case e.target.error.MEDIA_ERR_DECODE:
       showOnPage('The audio playback was aborted due to a corruption problem or because the video used features your browser did not support.');
       break;
     case e.target.error.MEDIA_ERR_SRC_NOT_SUPPORTED:
       if(!(e.target.paused)) {
		   showOnPage('The audio cannot be loaded, either because the server or network failed or because the format is not supported.');
	   }
       break;
     default:
       showOnPage('An unknown error occurred.');
       break;
 }});
 
 var source = document.createElement('source');
 source.type= 'audio/mp3';
 audioElement.appendChild(source);
 document.body.appendChild(audioElement);

 
 var HLS = (function () {
    var instance;
 
    function createInstance() {
        var object = new Hls();
        return object;
    }
 
    return {
        getInstance: function () {
            if (!instance) {
                instance = createInstance();
            }
            return instance;
        }
    };
})();




