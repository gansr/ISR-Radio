const MEDIA_ERR_ABORT = 'השמעת המדיה בוטלה';
const MEDIA_ERR_NETWORK = 'הורדת השמע נכשלה עקב שגיאת רשת';
const MEDIA_ERR_DECODE ='רכיב השמע הופסק עקב בעיה ברצועת ההשמעה או בגלל שהנגן לא נתמך בתכונות הדפדפן';
const MEDIA_ERR_SRC_NOT_SUPPORTED = 'לא ניתן לטעון את השמע, משום שהשרת או הרשת נכשלו או מפני שהתבנית אינה נתמכת';
const GENERAL_ERR = 'אירעה שגיאה לא ידועה';

function showOnPage(value){
	chrome.runtime.sendMessage({msg: value});
}

var audioElement = document.createElement('audio');
 audioElement.setAttribute("preload", "auto");
 audioElement.id = 'audioElement';
 audioElement.style.display = 'none';
 audioElement.autobuffer = true;

 audioElement.addEventListener("error", function(e) {
   switch (e.target.error.code) {
     case e.target.error.MEDIA_ERR_ABORTED:
       showOnPage(MEDIA_ERR_ABORT);
       break;
     case e.target.error.MEDIA_ERR_NETWORK:
	   showOnPage(MEDIA_ERR_NETWORK);
       break;
     case e.target.error.MEDIA_ERR_DECODE:
       showOnPage(MEDIA_ERR_DECODE);
       break;
     case e.target.error.MEDIA_ERR_SRC_NOT_SUPPORTED:
       if(!(e.target.paused)) {
		   showOnPage(MEDIA_ERR_SRC_NOT_SUPPORTED);
	   }
       break;
     default:
       showOnPage(GENERAL_ERR);
       break;
 }});
 
 var source = document.createElement('source');
 source.type= 'audio/mp3';
 audioElement.appendChild(source);
 document.body.appendChild(audioElement);

 
 var HLS = (function () {
    var instance;
 
    function createInstance() {
        var object = new Hls();
        return object;
    }
 
    return {
        getInstance: function () {
            if (!instance) {
                instance = createInstance();
            }
            return instance;
        }
    };
})();




