const idAudioElement = 'audioElement';
const idPlayingPrefix = '#playingPrefixMarkup';
const idPlayingSuffix = '#playingStation';
const idVolumeIcon = '#volumeIcon';
const idToaster = '#toaster';

const classVolumeButton = '.volumeBtn';
const classRadioStationItem = '.container-item';
const classPlayer = '.player';
const classPlaying = '.playing';
const classStopButton = '.stop';
const classMuteVolume = 'fa fa-volume-off';
const classDescription = '.desc';
const classNormalVolume = 'fa fa-volume-up';
const classMenuIcon = '.menuIcon';
const classTitle = '.title';
const classOverlay = '.overlay';
const classOptions = '.options';
const classOptionsStationUrl = '.stationUrl';
const classOptionsBtnCancel = '.optionsBtnCancel';
const classOptionsBtnSave = '.optionsBtnSave';
const classClosePopup = '.closePopupBtn';

const sourceUrlAttribute = 'data-audioUrl';
const hebPlaying = 'מנגן: ';

const radioStationUrlValuesStorageKey = 'radioStationsUrlValues';
const titleValues = ['בחר להאזנה','הגדרות'];

jQuery.fn.extend({
    toggleText: function (a, b){
        var that = this;
            if (that.text() != a && that.text() != b){
                that.text(a);
            }
            else
            if (that.text() == a){
                that.text(b);
            }
            else
            if (that.text() == b){
                that.text(a);
            }
        return this;
    }
});

function getPlayer(callback) {
  chrome.runtime.getBackgroundPage(function(page) {
    var player = page.document.getElementById(idAudioElement);
    callback(player);
  });
};

function getPlayerOptions(callback){
	chrome.runtime.getBackgroundPage(function(page) {
	var player = page.document.getElementById(idAudioElement);
	var hls = page.HLS.getInstance();
    callback(player,hls);
  });
}

function getHls(callback) {
	chrome.runtime.getBackgroundPage(function(page) {
    callback(page.HLS.getInstance());
  });
}

function clearPlayingView() {
	$(classRadioStationItem).removeClass(classPlaying);
	$(classPlayer).slideToggle();
}

function stopAudio(player){
	  player.pause();
	  player.currentTime = 0;
	  player.src = "";
}

function stopHls(hls){
	  hls.stopLoad();
	  hls.detachMedia();
}
  
function loadHlsMedia(hls,player){
	  hls.loadSource(player.src);
      hls.attachMedia(player);
}

function stopPlaying(player,hls){
	  stopAudio(player);
	  stopHls(hls);
}

function updatePlayingInfo(radioStationName){
	$(idPlayingPrefix).text(hebPlaying);
	$(idPlayingSuffix).text(radioStationName);
}

function toggleVolume(player){
	player.muted = !player.muted;
	var volumeIcon = $(idVolumeIcon);
	if(player.muted){
		volumeIcon.removeClass();
		volumeIcon.addClass(classMuteVolume);
	}
	else{
		volumeIcon.removeClass();
		volumeIcon.addClass(classNormalVolume);
	}
}

function updatePlayer(player, hls, context){
	player.src = $(context).attr(sourceUrlAttribute);
	player.dataset.stationName = $(context).find(classDescription).text();
	stopHls(hls);
	if(player.src.endsWith("m3u8")){
		loadHlsMedia(hls,player);
	}
	player.load(); 
	try
	{
		let playPromise = player.play();
		if (playPromise !== null){
			playPromise.catch(error => {
				if(!isPlaying(player)){
					$(classPlayer).hide();
				}
			});
		}
	}
	catch(e){
		stopPlaying(player,hls);
	}
}

function isPlaying(player){
	return (!player.paused || player.currentTime != 0);
}

function removePlayingStation(){
	getPlayerOptions((player,hls) => {
		stopPlaying(player,hls);
	});	
	$(classRadioStationItem).removeClass(classPlaying);
}

function initView(){
	getPlayer(function(player) {
		 if(!isPlaying(player)){
			$(classPlayer).hide();
		 }
		 else{
			 updatePlayingInfo(player.dataset.stationName);
		 }
	 });
}

function togglePlayingView(){
	if($(classPlayer).is(":hidden")){
		$(classPlayer).slideToggle("medium");
	}
}

function radioStationChanged(context,player){
	return $(context).attr(sourceUrlAttribute) !== player.src;
}

function markPlayingStation(context){
	$(context).addClass(classPlaying);
	$(classRadioStationItem).not(context).removeClass(classPlaying);
}

function createToaster()
{
    let toaster = window.document.createElement('div');
    toaster.id = "toaster";
	toaster.classname = '';
	return toaster;
}

function showToaster(msg){
  if($(idToaster).length == 0){
	window.document.body.appendChild(createToaster());
  }
  $(idToaster).text(msg);
  $(idToaster).slideToggle('medium');
  setTimeout(() => { $(idToaster).slideToggle('medium'); }, 5000);
}

function changeContextView(){
	$(classOverlay).slideToggle();
	$(classTitle).toggleText(titleValues[0],titleValues[1]);
}

function loadStationsUrlValues(){
	let radioStationItems = $(classRadioStationItem);
	$(classOptionsStationUrl).each(function(optionsStationUrlIndex, optionsStationUrlObject){
		optionsStationUrlObject.value = radioStationItems[optionsStationUrlIndex].getAttribute(sourceUrlAttribute);
	});
}

function saveOptions(){
	let resultObject = [];
	let optionsStationUrlItems = $(classOptionsStationUrl);
	$(classRadioStationItem).each(function(radioStationItemIndex, radioStationItemItem){
		resultObject.push(optionsStationUrlItems[radioStationItemIndex].value);
		radioStationItemItem.setAttribute(sourceUrlAttribute, optionsStationUrlItems[radioStationItemIndex].value);
	});
	addToStorage(radioStationUrlValuesStorageKey,resultObject);
	changeContextView();
	showToaster('Settings Successfully Updated!');
}

function addToStorage(key,value){
    let jsonObject = {};
    jsonObject[key] = JSON.stringify(value);
	chrome.storage.local.set(jsonfile, function(result) {
      console.log(`${key} - successfully saved in storage`);
    });
}

function getFromStorage(key,callback){
	chrome.storage.local.get(key,callback);
}

function initData(){
	getFromStorage(radioStationUrlValuesStorageKey,function(object){
		if(object != null && object[radioStationUrlValuesStorageKey] != null){
			var urlValues = JSON.parse(object[radioStationUrlValuesStorageKey]);
			$(classRadioStationItem).each(function(radioStationItemIndex, radioStationItemItem){
				radioStationItemItem.setAttribute(sourceUrlAttribute, urlValues[radioStationItemIndex]);
			});
		}
	});
}

function registerEventListeners(){
	//STOP MUSIC
  $(classStopButton).click(function(){
	   getPlayerOptions(function(player,hls) {
	   stopPlaying(player,hls);
	   clearPlayingView();
	   });
  });
  
  // MUTE/UNMUTE
  $(classVolumeButton).click(function(){
	  getPlayer(function(player) {
		  toggleVolume(player);
	  });
  });
  
  // PLAY MUSIC
  $(classRadioStationItem).click(function(){
	var context = this;
	getPlayerOptions((player,hls) => {
		if(radioStationChanged(context,player))
		{
			stopPlaying(player,hls);
			updatePlayingInfo($(context).find(classDescription).text());
			markPlayingStation(context);
			updatePlayer(player,hls,context);
			togglePlayingView();
		}
	});	
  });
  
  //OPEN MENU
  $(classMenuIcon).click(function(){
	  loadStationsUrlValues();
	  changeContextView();
  });
  
  //OPTIONS BUTTONS
  $(classOptionsBtnSave).click(function(){
	 saveOptions();
  });
  
  $(classOptionsBtnCancel).click(function(){
	  changeContextView();
  });
  
  // <Audio> ERROR MSGS LISTENER.
  chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		showToaster(`${request.msg}`);
		removePlayingStation();
	});
	
  // CLOSE POPUP
  $(classClosePopup).click(function(){
	 window.close(); 
  });
  
}


$(document).ready(function(){
	initData();
	initView();
	registerEventListeners();
 });